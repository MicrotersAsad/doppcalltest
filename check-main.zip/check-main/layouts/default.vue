<template>
  <div class="container">
    <slot> 
        
    </slot>
  </div>
</template>